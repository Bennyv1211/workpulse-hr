import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/context/AuthContext';

export default function RootLayout() {
  return (
    <AuthProvider>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="employee/[id]" options={{ presentation: 'card' }} />
        <Stack.Screen name="leave/request" options={{ presentation: 'modal' }} />
        <Stack.Screen name="payroll/[id]" options={{ presentation: 'card' }} />
      </Stack>
    </AuthProvider>
  );
}

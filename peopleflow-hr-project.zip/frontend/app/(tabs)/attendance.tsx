import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  Alert,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/context/AuthContext';
import { useHRStore } from '../../src/store/hrStore';
import { format, parseISO } from 'date-fns';

export default function AttendanceScreen() {
  const { user } = useAuth();
  const {
    todayAttendance,
    attendance,
    fetchTodayAttendance,
    fetchAttendance,
    clockIn,
    clockOut,
    isLoading,
  } = useHRStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    loadData();
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const loadData = async () => {
    await Promise.all([fetchTodayAttendance(), fetchAttendance()]);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleClockIn = async () => {
    try {
      await clockIn();
      Alert.alert('Success', 'You have clocked in successfully!');
    } catch (error: any) {
      Alert.alert('Error', error.message);
    }
  };

  const handleClockOut = async () => {
    try {
      await clockOut();
      Alert.alert('Success', 'You have clocked out successfully!');
    } catch (error: any) {
      Alert.alert('Error', error.message);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return '#10B981';
      case 'late':
        return '#F59E0B';
      case 'absent':
        return '#EF4444';
      default:
        return '#64748B';
    }
  };

  const renderAttendanceRecord = ({ item }: any) => (
    <View style={styles.recordCard}>
      <View style={styles.recordLeft}>
        <Text style={styles.recordDate}>
          {format(parseISO(item.date), 'EEE, MMM d')}
        </Text>
        <View style={[styles.statusChip, { backgroundColor: getStatusColor(item.status) + '20' }]}>
          <View style={[styles.statusDot, { backgroundColor: getStatusColor(item.status) }]} />
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
            {item.status}
          </Text>
        </View>
      </View>
      <View style={styles.recordRight}>
        <View style={styles.timeBlock}>
          <Text style={styles.timeLabel}>In</Text>
          <Text style={styles.timeValue}>
            {item.clock_in ? format(new Date(item.clock_in), 'HH:mm') : '--:--'}
          </Text>
        </View>
        <View style={styles.timeSeparator} />
        <View style={styles.timeBlock}>
          <Text style={styles.timeLabel}>Out</Text>
          <Text style={styles.timeValue}>
            {item.clock_out ? format(new Date(item.clock_out), 'HH:mm') : '--:--'}
          </Text>
        </View>
        <View style={styles.hoursBlock}>
          <Text style={styles.hoursValue}>
            {item.total_hours ? `${item.total_hours.toFixed(1)}h` : '-'}
          </Text>
        </View>
      </View>
    </View>
  );

  const isClockedIn = todayAttendance?.clock_in && !todayAttendance?.clock_out;
  const isClockedOut = todayAttendance?.clock_out;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Attendance</Text>
        <Text style={styles.currentDate}>{format(currentTime, 'EEEE, MMMM d, yyyy')}</Text>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Clock Card */}
        <View style={styles.clockCard}>
          <Text style={styles.currentTime}>{format(currentTime, 'HH:mm:ss')}</Text>
          
          <View style={styles.todayStatus}>
            {todayAttendance ? (
              <>
                <View style={styles.todayTimeBlock}>
                  <Ionicons name="log-in-outline" size={20} color="#10B981" />
                  <Text style={styles.todayTimeLabel}>Clock In</Text>
                  <Text style={styles.todayTimeValue}>
                    {todayAttendance.clock_in
                      ? format(new Date(todayAttendance.clock_in), 'HH:mm')
                      : '--:--'}
                  </Text>
                </View>
                <View style={styles.todayTimeBlock}>
                  <Ionicons name="log-out-outline" size={20} color="#EF4444" />
                  <Text style={styles.todayTimeLabel}>Clock Out</Text>
                  <Text style={styles.todayTimeValue}>
                    {todayAttendance.clock_out
                      ? format(new Date(todayAttendance.clock_out), 'HH:mm')
                      : '--:--'}
                  </Text>
                </View>
                {todayAttendance.total_hours && (
                  <View style={styles.todayTimeBlock}>
                    <Ionicons name="time-outline" size={20} color="#3B82F6" />
                    <Text style={styles.todayTimeLabel}>Hours</Text>
                    <Text style={styles.todayTimeValue}>
                      {todayAttendance.total_hours.toFixed(1)}h
                    </Text>
                  </View>
                )}
              </>
            ) : (
              <Text style={styles.notClockedText}>Not clocked in yet today</Text>
            )}
          </View>

          <View style={styles.clockButtons}>
            {!isClockedIn && !isClockedOut && (
              <TouchableOpacity
                style={[styles.clockButton, styles.clockInButton]}
                onPress={handleClockIn}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="finger-print" size={24} color="#FFFFFF" />
                    <Text style={styles.clockButtonText}>Clock In</Text>
                  </>
                )}
              </TouchableOpacity>
            )}
            
            {isClockedIn && (
              <TouchableOpacity
                style={[styles.clockButton, styles.clockOutButton]}
                onPress={handleClockOut}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="exit-outline" size={24} color="#FFFFFF" />
                    <Text style={styles.clockButtonText}>Clock Out</Text>
                  </>
                )}
              </TouchableOpacity>
            )}
            
            {isClockedOut && (
              <View style={styles.completedBadge}>
                <Ionicons name="checkmark-circle" size={24} color="#10B981" />
                <Text style={styles.completedText}>Day Complete</Text>
              </View>
            )}
          </View>
        </View>

        {/* Recent History */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent History</Text>
          {isLoading && attendance.length === 0 ? (
            <ActivityIndicator size="large" color="#3B82F6" style={{ marginTop: 20 }} />
          ) : attendance.length === 0 ? (
            <View style={styles.emptyHistory}>
              <Ionicons name="time-outline" size={48} color="#CBD5E1" />
              <Text style={styles.emptyText}>No attendance records yet</Text>
            </View>
          ) : (
            attendance.slice(0, 7).map((item) => (
              <View key={item.id}>
                {renderAttendanceRecord({ item })}
              </View>
            ))
          )}
        </View>

        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  currentDate: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 4,
  },
  scrollView: {
    flex: 1,
  },
  clockCard: {
    backgroundColor: '#FFFFFF',
    margin: 20,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  currentTime: {
    fontSize: 48,
    fontWeight: '300',
    color: '#1E293B',
    fontVariant: ['tabular-nums'],
  },
  todayStatus: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
    gap: 24,
  },
  todayTimeBlock: {
    alignItems: 'center',
    gap: 4,
  },
  todayTimeLabel: {
    fontSize: 12,
    color: '#64748B',
  },
  todayTimeValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
  },
  notClockedText: {
    fontSize: 14,
    color: '#94A3B8',
  },
  clockButtons: {
    marginTop: 24,
    width: '100%',
  },
  clockButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 14,
    gap: 10,
  },
  clockInButton: {
    backgroundColor: '#10B981',
  },
  clockOutButton: {
    backgroundColor: '#EF4444',
  },
  clockButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#D1FAE5',
    paddingVertical: 16,
    borderRadius: 14,
    gap: 8,
  },
  completedText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10B981',
  },
  section: {
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 12,
  },
  emptyHistory: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: '#94A3B8',
    marginTop: 12,
  },
  recordCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  recordLeft: {
    gap: 6,
  },
  recordDate: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E293B',
  },
  statusChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    alignSelf: 'flex-start',
    gap: 4,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'capitalize',
  },
  recordRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  timeBlock: {
    alignItems: 'center',
  },
  timeLabel: {
    fontSize: 10,
    color: '#94A3B8',
    marginBottom: 2,
  },
  timeValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#334155',
  },
  timeSeparator: {
    width: 12,
    height: 1,
    backgroundColor: '#E2E8F0',
  },
  hoursBlock: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  hoursValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#3B82F6',
  },
});
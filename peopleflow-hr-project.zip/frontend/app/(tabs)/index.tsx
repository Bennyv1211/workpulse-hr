import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/context/AuthContext';
import { useHRStore } from '../../src/store/hrStore';
import { useRouter } from 'expo-router';
import { format } from 'date-fns';

export default function DashboardScreen() {
  const { user } = useAuth();
  const router = useRouter();
  const {
    dashboardStats,
    fetchDashboardStats,
    fetchDepartments,
    fetchLeaveTypes,
    seedData,
    isLoading,
    employees,
    departments,
  } = useHRStore();
  const [refreshing, setRefreshing] = useState(false);
  const [seeding, setSeeding] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    await Promise.all([
      fetchDashboardStats(),
      fetchDepartments(),
      fetchLeaveTypes(),
    ]);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleSeedData = async () => {
    Alert.alert(
      'Seed Demo Data',
      'This will populate the system with demo employees, departments, and HR data. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Seed Data',
          onPress: async () => {
            setSeeding(true);
            try {
              await seedData();
              Alert.alert('Success', 'Demo data has been seeded successfully!');
            } catch (error: any) {
              Alert.alert('Note', error.message || 'Data may already be seeded');
            } finally {
              setSeeding(false);
            }
          },
        },
      ]
    );
  };

  const stats = dashboardStats;
  const isAdmin = user?.role === 'super_admin' || user?.role === 'hr_admin';

  const StatCard = ({ icon, label, value, color, onPress }: any) => (
    <TouchableOpacity style={styles.statCard} onPress={onPress} disabled={!onPress}>
      <View style={[styles.statIcon, { backgroundColor: color + '20' }]}>
        <Ionicons name={icon} size={24} color={color} />
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Welcome back,</Text>
          <Text style={styles.userName}>{user?.first_name} {user?.last_name}</Text>
        </View>
        <View style={styles.headerRight}>
          <View style={styles.roleChip}>
            <Text style={styles.roleText}>{user?.role?.replace('_', ' ')}</Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {isAdmin && (!stats || stats.total_employees === 0) && (
          <TouchableOpacity
            style={styles.seedButton}
            onPress={handleSeedData}
            disabled={seeding}
          >
            <Ionicons name="flash" size={20} color="#FFFFFF" />
            <Text style={styles.seedButtonText}>
              {seeding ? 'Seeding...' : 'Seed Demo Data'}
            </Text>
          </TouchableOpacity>
        )}

        {isLoading && !stats ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#3B82F6" />
          </View>
        ) : (
          <>
            {/* Quick Stats */}
            <View style={styles.statsGrid}>
              <StatCard
                icon="people"
                label="Total Employees"
                value={stats?.total_employees || 0}
                color="#3B82F6"
                onPress={() => router.push('/(tabs)/employees')}
              />
              <StatCard
                icon="checkmark-circle"
                label="Active"
                value={stats?.active_employees || 0}
                color="#10B981"
              />
              <StatCard
                icon="person-add"
                label="New Hires"
                value={stats?.new_hires_this_month || 0}
                color="#8B5CF6"
              />
              <StatCard
                icon="airplane"
                label="On Leave"
                value={stats?.employees_on_leave || 0}
                color="#F59E0B"
              />
            </View>

            {/* Pending Actions */}
            {isAdmin && stats?.pending_leave_requests > 0 && (
              <TouchableOpacity
                style={styles.pendingCard}
                onPress={() => router.push('/(tabs)/leave')}
              >
                <View style={styles.pendingIcon}>
                  <Ionicons name="hourglass" size={24} color="#F59E0B" />
                </View>
                <View style={styles.pendingContent}>
                  <Text style={styles.pendingTitle}>
                    {stats.pending_leave_requests} Pending Leave Request{stats.pending_leave_requests > 1 ? 's' : ''}
                  </Text>
                  <Text style={styles.pendingSubtitle}>Tap to review and approve</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#94A3B8" />
              </TouchableOpacity>
            )}

            {/* Attendance Today */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Today's Attendance</Text>
              <View style={styles.attendanceCard}>
                <View style={styles.attendanceRow}>
                  <View style={styles.attendanceItem}>
                    <View style={[styles.attendanceDot, { backgroundColor: '#10B981' }]} />
                    <Text style={styles.attendanceLabel}>Present</Text>
                    <Text style={styles.attendanceValue}>{stats?.attendance_today?.present || 0}</Text>
                  </View>
                  <View style={styles.attendanceItem}>
                    <View style={[styles.attendanceDot, { backgroundColor: '#F59E0B' }]} />
                    <Text style={styles.attendanceLabel}>Late</Text>
                    <Text style={styles.attendanceValue}>{stats?.attendance_today?.late || 0}</Text>
                  </View>
                  <View style={styles.attendanceItem}>
                    <View style={[styles.attendanceDot, { backgroundColor: '#EF4444' }]} />
                    <Text style={styles.attendanceLabel}>Absent</Text>
                    <Text style={styles.attendanceValue}>{stats?.attendance_today?.absent || 0}</Text>
                  </View>
                  <View style={styles.attendanceItem}>
                    <View style={[styles.attendanceDot, { backgroundColor: '#8B5CF6' }]} />
                    <Text style={styles.attendanceLabel}>Leave</Text>
                    <Text style={styles.attendanceValue}>{stats?.attendance_today?.on_leave || 0}</Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Department Breakdown */}
            {stats?.department_breakdown && stats.department_breakdown.length > 0 && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Departments</Text>
                <View style={styles.departmentsCard}>
                  {stats.department_breakdown.map((dept, index) => (
                    <View key={dept.department_id} style={styles.departmentRow}>
                      <Text style={styles.departmentName}>{dept.name}</Text>
                      <View style={styles.departmentCount}>
                        <Text style={styles.departmentCountText}>{dept.employee_count}</Text>
                      </View>
                    </View>
                  ))}
                </View>
              </View>
            )}

            {/* Upcoming Birthdays */}
            {stats?.upcoming_birthdays && stats.upcoming_birthdays.length > 0 && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Upcoming Birthdays</Text>
                <View style={styles.birthdaysCard}>
                  {stats.upcoming_birthdays.map((person, index) => (
                    <View key={person.employee_id} style={styles.birthdayRow}>
                      <View style={styles.birthdayAvatar}>
                        <Text style={styles.birthdayAvatarText}>
                          {person.name.split(' ').map(n => n[0]).join('')}
                        </Text>
                      </View>
                      <View style={styles.birthdayInfo}>
                        <Text style={styles.birthdayName}>{person.name}</Text>
                        <Text style={styles.birthdayDate}>
                          {person.days_until === 0 ? 'Today!' : `In ${person.days_until} days`}
                        </Text>
                      </View>
                      <Ionicons name="gift" size={20} color="#EC4899" />
                    </View>
                  ))}
                </View>
              </View>
            )}

            {/* Quick Actions */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Quick Actions</Text>
              <View style={styles.actionsGrid}>
                <TouchableOpacity
                  style={styles.actionCard}
                  onPress={() => router.push('/(tabs)/attendance')}
                >
                  <Ionicons name="finger-print" size={28} color="#3B82F6" />
                  <Text style={styles.actionText}>Clock In/Out</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.actionCard}
                  onPress={() => router.push('/leave/request')}
                >
                  <Ionicons name="calendar" size={28} color="#10B981" />
                  <Text style={styles.actionText}>Request Leave</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.actionCard}
                  onPress={() => router.push('/(tabs)/employees')}
                >
                  <Ionicons name="people" size={28} color="#8B5CF6" />
                  <Text style={styles.actionText}>Directory</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.actionCard}
                  onPress={() => router.push('/(tabs)/profile')}
                >
                  <Ionicons name="person" size={28} color="#F59E0B" />
                  <Text style={styles.actionText}>My Profile</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={{ height: 20 }} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  greeting: {
    fontSize: 14,
    color: '#64748B',
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  roleChip: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  roleText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#3B82F6',
    textTransform: 'capitalize',
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
  },
  seedButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#8B5CF6',
    marginHorizontal: 20,
    marginTop: 16,
    paddingVertical: 14,
    borderRadius: 12,
    gap: 8,
  },
  seedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    paddingTop: 16,
    gap: 12,
  },
  statCard: {
    width: '47%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  statLabel: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 4,
  },
  pendingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF3C7',
    marginHorizontal: 20,
    marginTop: 16,
    padding: 16,
    borderRadius: 12,
  },
  pendingIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#FDE68A',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  pendingContent: {
    flex: 1,
  },
  pendingTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#92400E',
  },
  pendingSubtitle: {
    fontSize: 13,
    color: '#B45309',
    marginTop: 2,
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 12,
  },
  attendanceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  attendanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  attendanceItem: {
    alignItems: 'center',
    flex: 1,
  },
  attendanceDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginBottom: 6,
  },
  attendanceLabel: {
    fontSize: 12,
    color: '#64748B',
    marginBottom: 4,
  },
  attendanceValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  departmentsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  departmentRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  departmentName: {
    fontSize: 14,
    color: '#334155',
  },
  departmentCount: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  departmentCountText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#3B82F6',
  },
  birthdaysCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  birthdayRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  birthdayAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FBCFE8',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  birthdayAvatarText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#BE185D',
  },
  birthdayInfo: {
    flex: 1,
  },
  birthdayName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1E293B',
  },
  birthdayDate: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    width: '47%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  actionText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#334155',
    marginTop: 8,
  },
});